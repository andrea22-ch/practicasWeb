<?php   include 'header.php'; 
include 'botones.php'?>
                

                <div class="row">
                    <div class="col-sm-8">
                         <?php include 'tabla_general.php'; ?>
                    </div>
                    <div class="col-sm-4">
                        <br><br>
                        <?php  include 'generales.php' ?>
                    </div>

                </div>
                 <br>
                    <?php include 'candidatos.php' ;
                   ?>
             </div>
        </body>
    </html>
