<p>

					<form action="" method="post" >
                       <select name="id_candidato" id="select" onchange=";this.form.submit();" >

                         <!--ESTE FOREACH RECORRE LA TABLA DE CANDIDATOS , Y LLENA EL CAMPO VALUE Y
                          Y LA INFORMACION MOSTRADA PARA CADA OPCION-->
                           <option onclick=""  value="">[Selecciona un candidato]</option>
                         <option onclick="" value="tabla_general">Todas las particiones</option>
                          <?php  foreach ($listaCandidatos as $candidato) { 
                           echo '<option onclick="" id="" value ="'.$candidato['id'].'">'.$candidato['nombre'].'</option>'; } ?> 
                        </select>
                        </form> 
                    </p>
                        <br><br>
                        <p>
                         <label >Total de participantes: <input type="text" maxlength="" disabled="" value="<?php echo $total_filas ?> "> </label>
                         <label >Cantidad de votos : <input type="text" maxlength="" disabled=""
                          value="<?php echo $candidato_cantidad; ?> "> </label>
                    </p>
