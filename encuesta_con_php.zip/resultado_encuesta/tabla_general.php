<div id="tabla_general">
                <br><br>
                <div class="col-md-12">
                        <table class="table-bordered" >
                            <tr>
                                <td>ID</td> 
                                <td>NOMBRE</td>
                                <td>FECHA HORA</td> 
                                <td>DATOS DEL PARTICIPANTE  </td> 
                            </tr>
                            <?php foreach ($listas as $candidato) {?>
                                <tr>
                                    <td><?php echo $candidato['id']; ?></td> 
                                    <td><?php echo $candidato['nombre']; ?></td> 
                                    <td><?php echo $candidato['fecha']; ?></td> 
                                    <td><?php echo $candidato['datos']; ?></td> 

                                </tr> <?php }   ?>
                        </table><!--FIN DE LA TABLA GENERAL DE ENCUESTAS--></div>
                        <br><br>

                    <!--PAGINACION DE LA TABLA GENERAL-->
                    <?php if($_GET['pagina']>$paginas || $_GET['pagina']<=0 ){
                            header('Location:tablas.php?pagina=1'); }  ?>

                            <nav aria-label="Page navigation example">
                            <ul class="pagination">
                             <li class="page-item  <?php 
                             echo $_GET['pagina']<=1 ? 'disabled' :''?>">

                             <a  class="page-link" 
                             href="tablas.php?pagina=<?php echo $_GET['pagina']-1?>">
                                 Anterior
                             </a>
                            </li>


                            <?php for($i=0;$i<$paginas;$i++):?>
                            <li class="page-item <?php echo $_GET['pagina']==$i+1 ? 'active' : '' ?>"><a class="page-link" href="tablas.php?pagina=<?php echo $i+1 ?>"><?php echo $i+1 ?></a></li><!--se crea la variable pagina-->
                        <?php endfor?>
                            

                             <li class="page-item  <?php 
                             echo $_GET['pagina']>=$paginas ? 'disabled' :''?>">

                             <a  class="page-link" 
                             href="tablas.php?pagina=<?php echo $_GET['pagina']+1?>">
                                Siguiente
                             </a>
                            </li>
                          </ul>
                        </nav>
                </div>