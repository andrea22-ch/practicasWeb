	<!-- this table list the information of count votes and porcentaje of each candidate elected -->

	<table class="table-bordered ">
		<tr>
			<td >Candidato</td>
			<td class="text-center">Cantidad</td>
			<td class="text-center">  %  </td>
		</tr>
	<?php
		/*nk=100*/
		$k=(100.00/ $total_filas);
		
	  foreach ($generales as $candidato) { ?>
	 <tr>
	 	<td><?php echo $candidato['nombre'] ?></td>
	 	<td class="text-center"><?php echo $candidato['votos'] ?></td>
	 	<td class="text-center"><?php echo number_format( $candidato['votos']*$k ,1);echo "%"; ;?></td>
	 </tr>
	<?php } ?>
	</table>
