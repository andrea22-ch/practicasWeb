
	
	
		         <!--EN ESTA DIVISION INICIA TODA LA INFORMACION POR CANDIDATO SELECIONADO DEL SELECT-->
              <div class="col-md-12" id="tabla_second" 
              style="display: block" >
                                <table class="table-bordered" >
                                    <tr>
                                        <td>ID</td> 
                                        <td>FECHA HORA</td> 
                                        <td>DATOS DEL PARTICIPANTE  </td> 
                                    </tr>
                                     <?php  foreach ($lista_candidato as $candidatolist) {   ?>
                                        <tr>
                                            <td><?php echo $candidatolist['id']; ?></td> 
                                            <td><?php echo $candidatolist['fecha']; ?></td> 
                                            <td><?php echo $candidatolist['datos']; ?></td> 

                                        </tr> <?php };
                                    ?>
                                </table>

                               
                      <br>
                      <br>
                      <br>
         </div>

