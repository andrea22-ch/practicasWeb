<?php

include 'globlal/config.php';
include 'globlal/conexion.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
      
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">     
         <link rel="stylesheet"
              href="https://fonts.googleapis.com/css?family=Tangerine">
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js" integrity="sha384-LtrjvnR4Twt/qOuYxE721u19sVFLVSA4hf/rRt6PrZTmiPltdZcI7q7PXQBYTKyf" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="links/css.css">
        <script src="links/cuentaregresiva.js"></script>

    </head>

 

   

        <div class="jumbotron-fluid text-center">
  <h1 class="display-4">Bienvenido!</h1>
   <div>Solo falta <div id='clock' >  </div> para las elecciones</div>
  <hr class="my-4">
  <p> Estas listo para elegir tu candidato?.</p>
</div>

             <div class="container-fluid sticky-top" id="header" > <h1>Encuesta electoral 2021
              <img class=""  src="img/depositphotos_16860383-stock-photo-flag-of-peru.jpg" alt="" height="20px"></h1></div>   


        <div class="container">
            <br><br>


            <form action="" method="post" name="miform" ">
                <!--QUery para listar todos los-->
                <?php
                $sentencia = $cn->prepare("SELECT * FROM `candidato`;");
                $sentencia->execute();
                $listaCandidatos = $sentencia->fetchAll(PDO::FETCH_ASSOC);
                //$gg=print_r($listaCandidatos);
                ?>

                <div class="row" >
                    <?php foreach ($listaCandidatos as $candidato) { ?>
                        <div class="col-lg-2 col-md-12 col-sm-6" style="margin-top:10px;padding: 5px">
                            <div class="card-success" >
                                <img  class="card-img-top img-fluid" src="img/<?php echo $candidato['img']; ?>" 
                                     alt="Card image cap" >
                                <div class="card-block">

                                    <p class="card-title"><?php echo $candidato['nombre']; ?></p>
                                    <p class="card-text">
                                        <input type="radio" id="id" name="id" value="<?php echo $candidato['id'] ?>" > Voto por él
                                    </p>

                                </div>
                            </div>

                        </div>
                    <?php } ?>
                </div>
                <br>                <br>
                <p class="text-center"><input type="radio" id="id" name="id" value=""> Prefiero no dar mi voto</p>
               <p class="text-center"> <input type="submit" value="Enviar " class="btn btn-info  btn-default" id="btn" ></p>


            </form>
            <?php
            if (isset($_POST['id'])) {/*recibe el name del radio button*/
                $opcion = $_POST['id'];
                if($opcion!= NULL){
                   $sentencia = $cn->prepare("INSERT INTO `encuesta` (`id`, `opcion`, `fecha`, `datos`) VALUES (NULL,:opcion, NOW(),'')");
                $sentencia->bindParam(':opcion', $opcion);
                $sentencia->execute();  
                }else{
                     $sentencia = $cn->prepare("INSERT INTO `votonulo` (`id`, `fecha`, `datos`) VALUES (NULL, NOW(), '');");
          
                $sentencia->execute();  
                }
               
            }
            ?>

           



        </div  >
<!--footer y comtacyos-->
            <div class="section" id="contacts" style="text-align: center;">
                
                <a href="#">
                    <img alt="Facebook" src="https://www.sololearn.com/Uploads/icons/facebook.png"/>
                </a>
                <a href="#">
                    <img alt="Twitter" src="https://www.sololearn.com/Uploads/icons/twitter.png" />
                </a>
            </div>
        </div>
        <?php
        // put your code here
        ?>
    </body>
</html>
