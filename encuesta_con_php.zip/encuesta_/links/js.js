
function mostrar (){
var selectoption=document.getElementById('select').value;
var tabla_general=document.getElementById('tabla_general');
var tabla_candidato=document.getElementById('tabla_second');
if(selectoption==="tabla_general" || selectoption==="" ){
	tabla_general.style.display = 'block';
		tabla_candidato.style.display = 'none';
		console.log(selectoption);
	

		
}else{
	tabla_general.style.display = 'none';
	tabla_candidato.style.display = 'block';
}
}

/*
const dd=()=>{
var selectoption=document.getElementById('id_candidato ').value;
var tabla_general=document.getElementById('tabla_general');
var tabla_candidato=document.getElementById('tabla_second');
if(selectoption==="tabla_general" || selectoption="" ){
		tabla_general.style.display = 'block';
		tabla_candidato.style.display = 'none';
}else{
	tabla_general.style.display = 'none';
	tabla_candidato.style.display = 'block';
}

};*/





