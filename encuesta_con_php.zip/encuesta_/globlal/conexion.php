<?php

$servidor="mysql:dbname=".BD.";host=".SERVIDOR;
try{
    $cn=new PDO($servidor,USUARIO,PASSWORD,
    array(PDO::MYSQL_ATTR_INIT_COMMAND=>"SET NAMES utf8" ));

} catch (Exception $ex) {
echo '<script>alert("error...")</script>';
}
