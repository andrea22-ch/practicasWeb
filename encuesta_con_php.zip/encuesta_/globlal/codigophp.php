 <?php 
               /*QUERY PARA RELLENAR EL SELECT   this is for bring the button select */
                    $sentencia_c = $cn->prepare("SELECT * FROM `candidato`;");
                    $sentencia_c->execute();
                    $listaCandidatos = $sentencia_c->fetchAll(PDO::FETCH_ASSOC);
                   /*---------*/?>

                    <?php if(!$_GET){header('Location:tablas.php?pagina=1'); } ?>

                 <!--QUERY PARA QUE RELLENAR LA TABLA GENERAL-->
                <?php
                $sentencia_en = $cn->prepare("SELECT e.id,c.nombre,e.fecha,e.datos FROM encuesta e INNER join candidato c on c.id=e.opcion;");
                $sentencia_en->execute(); ?>

                 <?php

                $articulos_x_pagina=13;
                $total_filas=$sentencia_en->rowCount();//CALCULA EL NUMERO DE FILAS
                $paginas=ceil($total_filas/13);
                $iniciar=($_GET['pagina']-1)*$articulos_x_pagina;

                /*CODIGO PARA RELLENAR LA TABLA GENERAL SEGUN EL NUMERO DE*/
                $lista= $cn->prepare("SELECT e.id,c.nombre,e.fecha,e.datos FROM encuesta e INNER join candidato c on c.id=e.opcion limit :iniciar,13");
                 $lista->bindParam(':iniciar',$iniciar,PDO::PARAM_INT);   
                $lista->execute();
                $listas = $lista->fetchAll(PDO::FETCH_ASSOC);   ?> 


         
<!--Desde el boton select:
 ESTE CODIGO PHP REPRESENTA LA SOLICITUD DE INFORMACION DE VOTACIONES POR EL 
                ID DEL CANDIDATO A LA TABLA GENERAL DE ENCUESTA -->
               <?php 
               $lista_candidato=[]; $candidato_cantidad=0;$opcion=0;$page=0;
              if (isset($_POST["id_candidato"])) {
                $opcion = $_POST["id_candidato"];
                $sql = $cn->prepare("SELECT e.id,e.fecha,e.datos FROM encuesta e INNER join candidato c on c.id= e.opcion WHERE c.id= :opcion");
                $sql->bindParam(':opcion', $opcion);  
                $sql->execute();
                $candidato_cantidad=$sql->rowCount();
                /*  $lista_candidato=$sql->fetchAll(PDO::FETCH_ASSOC);*/

                $articulos=13;
                 $page=ceil($candidato_cantidad/13);
                  $inicio=0;

                   $sql_paginas = $cn->prepare("SELECT e.id,e.fecha,e.datos FROM encuesta e INNER join candidato c on c.id= e.opcion WHERE c.id= :opcion LIMIT :inicio,13");
                   $sql_paginas->bindParam(':opcion', $opcion);
                    $sql_paginas->bindParam(':inicio',$inicio,PDO::PARAM_INT);
                    $sql_paginas->execute();
                  
                 
                 $lista_candidato=$sql_paginas->fetchAll(PDO::FETCH_ASSOC);}
                          ?>

<?php 
/*lista los candidatos con sus numero de  votos*/
$sql_other=$cn->prepare( "SELECT c.nombre,count(e.opcion) as votos FROM encuesta e INNER join candidato c on c.id=e.opcion GROUP BY c.nombre ORDER by c.nombre") ;
$sql_other->execute();

$generales=$sql_other->fetchAll(PDO::FETCH_ASSOC);

?>


