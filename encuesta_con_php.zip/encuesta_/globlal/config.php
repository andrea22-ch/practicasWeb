<?php
define("SERVIDOR", "localhost");
define("USUARIO","root");
define("PASSWORD","");
define("BD", "encuestaselectorales");

    