-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 05-02-2021 a las 18:07:26
-- Versión del servidor: 10.4.17-MariaDB
-- Versión de PHP: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `encuestaselectorales`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `candidato`
--

CREATE TABLE `candidato` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `img` varchar(100) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `candidato`
--

INSERT INTO `candidato` (`id`, `nombre`, `img`) VALUES
(1, 'Yonhy Lescano - Acción Popular', 'lescano_ulas1n.jpg'),
(2, ' Pedro Castillo - Perú Libre', 'pedrocastillo_onsqxl.jpg\r\n'),
(3, ' Julio Guzmán -Partido Morado', 'julioguzman_uk1atx.jpg'),
(4, ' Rafael López Aliaga -RP', 'rafael_rp_k5oscg.jpg\r\n'),
(5, ' Keiko Fujimori - Fuerza Popular', 'keiko_xnqkua.jpg\r\n'),
(6, ' Hernando de Soto - Alianza País', 'desoto_mzp1gj.jpg'),
(7, 'Verónika Mendoza -Juntos', 'veronika_gcw6dw.jpg'),
(8, 'Andrés Alcántara - Democracia Directa', 'alcantara_rsbmew.jpg'),
(9, 'Alberto Beingolea -PPC', 'Alberto_Beingolea.jpg'),
(10, ' George Forsyth -Victoria Nacional', 'forsayt_efgfjq.jpg'),
(11, ' Marco Arana - Frente Amplio', 'marco_arana_msjpm5.jpg'),
(12, 'José Vega- UPP', 'josevega_hxr0gg.jpg'),
(13, 'Daniel Urresti -Podemos', 'urresti_egglkc.jpg'),
(14, 'Daniel Salaverry -Somos Perú', 'salaverry_wz6iuq.jpg\r\n'),
(15, 'Ciro Gálvez -RUNA', 'ciroGalvez_tctn8k.jpg'),
(16, 'Ollanta Humala -Partido Nacionalista', 'ollanta_qsfy6h.jpg'),
(17, ' Fernando Olivera- Frente Esperanza', 'olivera_fdelbw.jpg'),
(18, ' César Acuña -Alianza Progreso', 'acunna_yi0jfq.jpg'),
(19, ' Fernando Cillóniz- Todos Por el Perú', 'cillinoiz_vxerbf.jpg'),
(20, ' Rafael Santos -Patria Segura', 'rafael_psp_abxb7u.jpg'),
(21, 'Pedro Angulo-Contigo Perú', 'angulo_j1zz3k.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encuesta`
--

CREATE TABLE `encuesta` (
  `id` int(11) NOT NULL,
  `opcion` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `datos` varchar(100) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `encuesta`
--

INSERT INTO `encuesta` (`id`, `opcion`, `fecha`, `datos`) VALUES
(1, 1, '2021-01-21 13:00:36', ''),
(2, 21, '2021-01-21 13:00:45', ''),
(3, 4, '2021-01-21 13:00:51', ''),
(4, 21, '2021-01-21 20:23:10', ''),
(5, 18, '2021-01-21 20:34:43', ''),
(6, 18, '2021-01-21 21:06:46', ''),
(7, 18, '2021-01-21 21:07:11', ''),
(8, 4, '2021-02-04 06:39:20', 'anndrea condoir hauyunga '),
(9, 21, '2021-02-05 10:53:00', ''),
(10, 21, '2021-02-05 11:04:29', '');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `candidato`
--
ALTER TABLE `candidato`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `encuesta`
--
ALTER TABLE `encuesta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `opcion` (`opcion`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `candidato`
--
ALTER TABLE `candidato`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `encuesta`
--
ALTER TABLE `encuesta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `encuesta`
--
ALTER TABLE `encuesta`
  ADD CONSTRAINT `encuesta_ibfk_1` FOREIGN KEY (`opcion`) REFERENCES `candidato` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
